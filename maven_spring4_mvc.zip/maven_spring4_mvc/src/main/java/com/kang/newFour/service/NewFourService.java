package com.kang.newFour.service;

import com.kang.newThreePointOne.model.NewUser;

public interface NewFourService  extends IbaseService<NewUser, Integer>{

}
