package com.kang.newFour.dao;

import com.kang.newThreePointOne.model.NewUser;

public interface InewFourDao extends IBaseDao<NewUser,Integer> {
	
	

}
