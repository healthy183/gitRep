package com.kang.newThreePointOne.model;

public class MyArgumentUser implements java.io.Serializable {

	public Integer argumentUsrId;
	public String argumentUsrName;
	public String argumentUsrSwd;
	
	
	public Integer getArgumentUsrId() {
		return argumentUsrId;
	}
	public void setArgumentUsrId(Integer argumentUsrId) {
		this.argumentUsrId = argumentUsrId;
	}
	public String getArgumentUsrName() {
		return argumentUsrName;
	}
	public void setArgumentUsrName(String argumentUsrName) {
		this.argumentUsrName = argumentUsrName;
	}
	public String getArgumentUsrSwd() {
		return argumentUsrSwd;
	}
	public void setArgumentUsrSwd(String argumentUsrSwd) {
		this.argumentUsrSwd = argumentUsrSwd;
	}
	
	
	
	
}
