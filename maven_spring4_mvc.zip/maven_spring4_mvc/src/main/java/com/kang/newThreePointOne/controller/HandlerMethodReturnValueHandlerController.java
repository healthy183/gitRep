package com.kang.newThreePointOne.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kang.newThreePointOne.model.NewUser;

@Scope("prototype")
@Controller
@RequestMapping("/handlerController")
public class HandlerMethodReturnValueHandlerController {

	
	@RequestMapping("/testNewUser")
	public NewUser testNewUser(){
	
		NewUser usr = new NewUser();
		usr.setUsrName("梁健康");
		usr.setUsrSwd("Swd@1234");
		return usr;
	}
	
	
	
}
