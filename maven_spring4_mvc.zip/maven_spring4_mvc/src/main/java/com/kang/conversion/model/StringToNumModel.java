package com.kang.conversion.model;

import java.util.Date;

public class StringToNumModel {

	private PhoneNumberModel model;
	
	private Date conversionDate;
	
	public Date getConversionDate() {
		return conversionDate;
	}

	public void setConversionDate(Date conversionDate) {
		this.conversionDate = conversionDate;
	}

	public PhoneNumberModel getModel() {
		return model;
	}

	public void setModel(PhoneNumberModel model) {
		this.model = model;
	}
	
	
	
	
}
